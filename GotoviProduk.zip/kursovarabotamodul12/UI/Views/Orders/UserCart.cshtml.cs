using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UI.Views.Orders
{
    public class UserCartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
