using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UI.Views.Orders
{
    public class AdminOrderDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
