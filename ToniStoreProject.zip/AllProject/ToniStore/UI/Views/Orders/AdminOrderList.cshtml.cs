using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UI.Views.Orders
{
    public class AdminOrderListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
